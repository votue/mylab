<?php


class Less_Exception_Parser extends Exception{

}